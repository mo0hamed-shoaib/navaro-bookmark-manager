import { BookmarkManager } from "@/components/bookmark-manager";

export default function Home() {
  return <BookmarkManager />;
}
